import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { Mail, Phone, MapPin } from 'lucide-react';
import 'leaflet/dist/leaflet.css';

const contactSchema = Yup.object().shape({
  name: Yup.string().required('Name is required'),
  email: Yup.string().email('Invalid email').required('Email is required'),
  message: Yup.string().required('Message is required'),
});

export default function Contact() {
  const [formRef, formInView] = useInView({ triggerOnce: true });
  const position = [51.505, -0.09]; // London coordinates

  return (
    <div className="pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Get in Touch
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400">
            We'd love to hear from you. Send us a message, and we'll respond as soon as possible.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Contact Form */}
          <motion.div
            ref={formRef.ref}
            initial={{ opacity: 0, x: -20 }}
            animate={formInView ? { opacity: 1, x: 0 } : {}}
            className="bg-white dark:bg-gray-900 rounded-xl shadow-lg p-8"
          >
            <Formik
              initialValues={{ name: '', email: '', message: '' }}
              validationSchema={contactSchema}
              onSubmit={(values, { setSubmitting, resetForm }) => {
                setTimeout(() => {
                  alert(JSON.stringify(values, null, 2));
                  setSubmitting(false);
                  resetForm();
                }, 400);
              }}
            >
              {({ errors, touched }) => (
                <Form className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Name
                    </label>
                    <Field
                      name="name"
                      className={`mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-pink-500 focus:ring-pink-500 dark:bg-gray-800 dark:border-gray-700 ${
                        errors.name && touched.name ? 'border-red-500' : ''
                      }`}
                    />
                    {errors.name && touched.name && (
                      <div className="text-red-500 text-sm mt-1">{errors.name}</div>
                    )}
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Email
                    </label>
                    <Field
                      name="email"
                      type="email"
                      className={`mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-pink-500 focus:ring-pink-500 dark:bg-gray-800 dark:border-gray-700 ${
                        errors.email && touched.email ? 'border-red-500' : ''
                      }`}
                    />
                    {errors.email && touched.email && (
                      <div className="text-red-500 text-sm mt-1">{errors.email}</div>
                    )}
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Message
                    </label>
                    <Field
                      name="message"
                      as="textarea"
                      rows={4}
                      className={`mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-pink-500 focus:ring-pink-500 dark:bg-gray-800 dark:border-gray-700 ${
                        errors.message && touched.message ? 'border-red-500' : ''
                      }`}
                    />
                    {errors.message && touched.message && (
                      <div className="text-red-500 text-sm mt-1">{errors.message}</div>
                    )}
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    type="submit"
                    className="w-full px-4 py-2 bg-pink-500 text-white rounded-md hover:bg-pink-600 transition-colors"
                  >
                    Send Message
                  </motion.button>
                </Form>
              )}
            </Formik>
          </motion.div>

          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={formInView ? { opacity: 1, x: 0 } : {}}
            className="space-y-8"
          >
            <div className="bg-white dark:bg-gray-900 rounded-xl shadow-lg p-8">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
                Contact Information
              </h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <Mail className="h-6 w-6 text-pink-500" />
                  <span className="text-gray-600 dark:text-gray-400">
                    contact@loveme.com
                  </span>
                </div>
                <div className="flex items-center space-x-4">
                  <Phone className="h-6 w-6 text-pink-500" />
                  <span className="text-gray-600 dark:text-gray-400">
                    +1 (555) 123-4567
                  </span>
                </div>
                <div className="flex items-center space-x-4">
                  <MapPin className="h-6 w-6 text-pink-500" />
                  <span className="text-gray-600 dark:text-gray-400">
                    123 Love Street, London, UK
                  </span>
                </div>
              </div>
            </div>

            {/* Map */}
            <div className="h-64 bg-gray-100 dark:bg-gray-800 rounded-xl overflow-hidden shadow-lg">
              <MapContainer
                center={position}
                zoom={13}
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                />
                <Marker position={position}>
                  <Popup>
                    Love Me Headquarters
                  </Popup>
                </Marker>
              </MapContainer>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
