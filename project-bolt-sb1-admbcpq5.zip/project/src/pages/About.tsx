import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Heart, Star, Award, Users } from 'lucide-react';

const milestones = [
  {
    year: '2020',
    title: 'Love Me Founded',
    description: 'Started with a vision to revolutionize online dating.',
    icon: Heart,
  },
  {
    year: '2021',
    title: '1 Million Users',
    description: 'Reached our first million active users worldwide.',
    icon: Users,
  },
  {
    year: '2022',
    title: 'Award Winning Platform',
    description: 'Recognized as the best dating platform of the year.',
    icon: Award,
  },
  {
    year: '2023',
    title: 'Global Expansion',
    description: 'Now available in over 50 countries worldwide.',
    icon: Star,
  },
];

export default function About() {
  const [headerRef, headerInView] = useInView({ triggerOnce: true });
  const [timelineRef, timelineInView] = useInView({ triggerOnce: true });

  return (
    <div className="pt-16">
      {/* Header Section */}
      <motion.section
        ref={headerRef}
        initial={{ opacity: 0, y: 20 }}
        animate={headerInView ? { opacity: 1, y: 0 } : {}}
        className="py-20 bg-white dark:bg-gray-900"
      >
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-6">
            Our Story
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400">
            Love Me was founded with a simple mission: to help people find meaningful connections
            in an increasingly digital world. We believe that everyone deserves to find their
            perfect match, and we're here to make that happen.
          </p>
        </div>
      </motion.section>

      {/* Timeline Section */}
      <section
        ref={timelineRef}
        className="py-20 bg-gray-50 dark:bg-gray-800"
      >
        <div className="max-w-7xl mx-auto px-4">
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-pink-200 dark:bg-pink-900" />

            {/* Timeline Items */}
            {milestones.map((milestone, index) => {
              const Icon = milestone.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={timelineInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: index * 0.2 }}
                  className={`relative flex items-center justify-between mb-8 ${
                    index % 2 === 0 ? 'flex-row-reverse' : ''
                  }`}
                >
                  <div className="w-5/12" />
                  <div className="absolute left-1/2 transform -translate-x-1/2 -translate-y-4">
                    <div className="w-8 h-8 rounded-full bg-pink-500 flex items-center justify-center">
                      <Icon className="h-4 w-4 text-white" />
                    </div>
                  </div>
                  <div className="w-5/12 bg-white dark:bg-gray-900 p-6 rounded-xl shadow-lg">
                    <div className="flex items-center mb-2">
                      <span className="text-pink-500 font-bold">{milestone.year}</span>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                      {milestone.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      {milestone.description}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}